import React from 'react'
import '../App.css'
const header = () => {
  return (
    <div className='header'>
      <h4><center>Book Store</center></h4>
    </div>
  )
}

export default header;
