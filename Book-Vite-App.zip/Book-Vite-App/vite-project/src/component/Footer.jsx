import React from 'react'
import '../App.css'
function footer() {
  return (
    <div className='footer'>
      <h2><center>made with &heart; </center></h2>
    </div>
  )
}

export default footer;
